$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

Write-Host "=== MultiRoof Windows Build ===" -ForegroundColor Cyan

$required = @(
    "main.py",
    "multiroof.spec",
    "requirements-build.txt",
    "UI\MainWindow.py",
    "UI\DialogSettings.py",
    "UI\DialogAbout.py",
    "UI\config_io.py",
    "UI\resource_utils.py",
    "UI\mainWindow.ui",
    "UI\dialogSettings.ui",
    "UI\dialogAbout.ui",
    "installer\installer_windows.iss",
    "icons\MultiRoof.ico",
    "UI\resources\logo_interreg.png",
    "UI\resources\logo_ulb.png",
    "UI\resources\logo_mlg.png"
)

$missing = $required | Where-Object { -not (Test-Path $_) }
if ($missing) {
    Write-Host "Missing required files:" -ForegroundColor Red
    $missing | ForEach-Object { Write-Host "  $_" -ForegroundColor Red }
    exit 1
}

if (-not (Get-Command py -ErrorAction SilentlyContinue)) {
    throw "Python launcher 'py' was not found. Install 64-bit Python 3.11+ first."
}

if (-not (Test-Path ".venv")) {
    py -3 -m venv .venv
}

$python = Join-Path $PSScriptRoot ".venv\Scripts\python.exe"
$pyinstaller = Join-Path $PSScriptRoot ".venv\Scripts\pyinstaller.exe"

& $python -m pip install --upgrade pip
& $python -m pip install -r requirements-build.txt

if (Test-Path "build") { Remove-Item "build" -Recurse -Force }
if (Test-Path "dist") { Remove-Item "dist" -Recurse -Force }
if (Test-Path "installer_output") { Remove-Item "installer_output" -Recurse -Force }

Write-Host "Building application with PyInstaller..." -ForegroundColor Cyan
& $pyinstaller --noconfirm --clean multiroof.spec

$exe = Join-Path $PSScriptRoot "dist\MultiRoof\MultiRoof.exe"
if (-not (Test-Path $exe)) {
    throw "PyInstaller did not create dist\MultiRoof\MultiRoof.exe"
}

Write-Host "Executable created: $exe" -ForegroundColor Green

$innoCandidates = @(
    "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe",
    "${env:ProgramFiles}\Inno Setup 6\ISCC.exe"
)
$iscc = $innoCandidates | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1

if (-not $iscc) {
    Write-Host "" 
    Write-Host "Inno Setup 6 not found." -ForegroundColor Yellow
    Write-Host "The executable is ready, but the installer was not created."
    Write-Host "Install Inno Setup 6 and run build_windows.bat again."
    exit 0
}

Write-Host "Building installer with Inno Setup..." -ForegroundColor Cyan
& $iscc "installer\installer_windows.iss"

$installer = Join-Path $PSScriptRoot "installer_output\MultiRoofSetup.exe"
if (-not (Test-Path $installer)) {
    throw "Inno Setup did not create installer_output\MultiRoofSetup.exe"
}

Write-Host "" 
Write-Host "SUCCESS" -ForegroundColor Green
Write-Host "Application: $exe"
Write-Host "Installer:   $installer"
