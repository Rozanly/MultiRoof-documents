#define MyAppName "MultiRoof"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "MultiRoofs"
#define MyAppExeName "MultiRoof.exe"

[Setup]
AppId={{A4948B72-9C6B-47B9-8459-E994F8D00B3F}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\MultiRoof
DefaultGroupName=MultiRoof
OutputDir=..\installer_output
OutputBaseFilename=MultiRoofSetup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
UninstallDisplayIcon={app}\{#MyAppExeName}
SetupIconFile=..\icons\MultiRoof.ico
PrivilegesRequired=admin

[Files]
Source: "..\dist\MultiRoof\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\MultiRoof"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\MultiRoof"; Filename: "{app}\{#MyAppExeName}"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch MultiRoof"; Flags: nowait postinstall skipifsilent
