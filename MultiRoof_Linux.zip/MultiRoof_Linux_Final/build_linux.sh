#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"
echo "=== MultiRoof Linux build ==="

required=(
  "main.py"
  "multiroof_linux.spec"
  "UI/MainWindow.py"
  "UI/DialogSettings.py"
  "UI/DialogAbout.py"
  "UI/mainWindow.ui"
  "UI/dialogSettings.ui"
  "UI/dialogAbout.ui"
  "UI/resources/logo_interreg.png"
  "UI/resources/logo_ulb.png"
  "UI/resources/logo_mlg.png"
  "icons/MultiRoof.png"
)
for f in "${required[@]}"; do
  [[ -f "$f" ]] || { echo "Missing required file: $f"; exit 1; }
done

python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements-build.txt

rm -rf build dist MultiRoof.AppDir
pyinstaller --noconfirm --clean multiroof_linux.spec

echo "PyInstaller application created: dist/MultiRoof/MultiRoof"

mkdir -p MultiRoof.AppDir/usr/bin
cp -a dist/MultiRoof MultiRoof.AppDir/usr/bin/
cp multiroof.desktop MultiRoof.AppDir/
cp icons/MultiRoof.png MultiRoof.AppDir/multiroof.png
cp AppRun MultiRoof.AppDir/AppRun
chmod +x MultiRoof.AppDir/AppRun
chmod +x MultiRoof.AppDir/usr/bin/MultiRoof/MultiRoof

APPIMAGETOOL=""
if command -v appimagetool >/dev/null 2>&1; then
  APPIMAGETOOL="$(command -v appimagetool)"
elif [[ -x "./appimagetool-x86_64.AppImage" ]]; then
  APPIMAGETOOL="./appimagetool-x86_64.AppImage"
fi

if [[ -z "$APPIMAGETOOL" ]]; then
  echo
  echo "PyInstaller build and AppDir are ready."
  echo "appimagetool was not found, so the final AppImage was not created."
  echo "Place appimagetool-x86_64.AppImage in this folder, make it executable,"
  echo "and run ./build_linux.sh again."
  exit 0
fi

ARCH=x86_64 "$APPIMAGETOOL" MultiRoof.AppDir MultiRoof-x86_64.AppImage

echo
echo "SUCCESS"
echo "Linux application: dist/MultiRoof/MultiRoof"
echo "AppImage: MultiRoof-x86_64.AppImage"
