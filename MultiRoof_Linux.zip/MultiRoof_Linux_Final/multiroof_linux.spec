# -*- mode: python ; coding: utf-8 -*-
from pathlib import Path

project_root = Path(SPEC).resolve().parent
ui_dir = project_root / "UI"

datas = [
    (str(ui_dir / "mainWindow.ui"), "UI"),
    (str(ui_dir / "dialogSettings.ui"), "UI"),
    (str(ui_dir / "dialogAbout.ui"), "UI"),
    (str(project_root / "icons" / "MultiRoof.png"), "icons"),
]

resources_dir = ui_dir / "resources"
if resources_dir.is_dir():
    for resource in resources_dir.rglob("*"):
        if resource.is_file():
            destination = Path("UI") / "resources" / resource.parent.relative_to(resources_dir)
            datas.append((str(resource), str(destination)))

a = Analysis(
    [str(project_root / "main.py")],
    pathex=[str(project_root)],
    binaries=[],
    datas=datas,
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="MultiRoof",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    name="MultiRoof",
)
