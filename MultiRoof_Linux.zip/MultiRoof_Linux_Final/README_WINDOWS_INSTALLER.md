# MultiRoof Windows installer

This folder contains the complete Windows packaging source for the current MultiRoof GUI.

## What the final installer contains

PyInstaller bundles the Python runtime, PyQt6, tomlkit and the application code. The end user does **not** need Python or PyQt6 installed.

Roofer is deliberately **not** included. The user chooses the Roofer executable through the application's Settings dialog.

## Build requirements (developer/build computer only)

1. Windows 10/11 64-bit
2. Python 3.11 or newer (64-bit), with the `py` launcher
3. Inno Setup 6

## Build

Double-click:

`build_windows.bat`

The script creates a local virtual environment, installs the build requirements, runs PyInstaller, then runs Inno Setup.

## Output

After a successful build:

- Standalone application: `dist\MultiRoof\MultiRoof.exe`
- Installer: `installer_output\MultiRoofSetup.exe`

Give `MultiRoofSetup.exe` to Windows users.

## Recommended clean-machine test

Test the installer on a Windows machine/VM without Python installed. Verify:

- application starts from Start Menu and Desktop shortcut
- Settings can select an external Roofer executable
- LAS/LAZ file mode and folder mode work
- footprint, TOML and output-folder browsing work
- Roofer starts/stops correctly
- CityJSON output is detected
- CityJSON Ninja opens and the “Don't show this message again” setting persists
- log copy/save work
- session settings persist after restart
- uninstall works

## Optional About-dialog logos

`DialogAbout.py` looks for these optional files under `UI\resources\`:

- `logo_interreg.png`
- `logo_ulb.png`
- `logo_mlg.png`

If they are absent, the About dialog hides the logo area. If you add them before building, the spec automatically bundles them.

## Fixed packaged resources

This release explicitly packages the three About-dialog logos:
- `UI/resources/logo_interreg.png`
- `UI/resources/logo_ulb.png`
- `UI/resources/logo_mlg.png`

It also packages `icons/MultiRoof.ico` as a runtime resource and sets it as
the Qt application window icon. The same icon remains configured for the
PyInstaller executable and the Inno Setup installer.

Rebuild from a clean state by closing MultiRoof and running:

    build_windows.bat

Then distribute the newly generated:

    installer_output\MultiRoofSetup.exe
