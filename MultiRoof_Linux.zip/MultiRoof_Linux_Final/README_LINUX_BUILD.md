# MultiRoof Linux build

This package builds the Linux version of MultiRoof from the same application
source used for the Windows release. Roofer is NOT bundled.

## Recommended build environment

Use a 64-bit Linux machine/VM, preferably Ubuntu 22.04 LTS or another suitably
old supported Linux distribution. PyInstaller Linux builds should be created
on Linux, not Windows.

## Build

Open a terminal in this extracted folder:

    chmod +x build_linux.sh AppRun
    ./build_linux.sh

The script creates a virtual environment, installs the Python build
dependencies, and creates:

    dist/MultiRoof/MultiRoof

It also prepares:

    MultiRoof.AppDir/

## Create the AppImage

The script will create `MultiRoof-x86_64.AppImage` automatically when
`appimagetool` is installed or when `appimagetool-x86_64.AppImage` is placed
in the project folder and made executable:

    chmod +x appimagetool-x86_64.AppImage
    ./build_linux.sh

Final distributable:

    MultiRoof-x86_64.AppImage

The About dialog resources (Interreg/MultiRoofs, ULB, MLG) and the MultiRoof
application icon are bundled.

## Test

Test the AppImage on a second Linux machine that does not have your Python
development environment. Roofer remains external and should be selected from
the application's Settings dialog.
